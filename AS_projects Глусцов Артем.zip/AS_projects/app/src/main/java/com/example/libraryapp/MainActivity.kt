package com.example.libraryapp

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                LibraryAppScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryAppScreen(viewModel: LibraryViewModel = viewModel()) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Управління Бібліотекою (Лаб 3)") }) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    label = { Text("Каталог") },
                    icon = {}
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    label = { Text("+ Книга") },
                    icon = {}
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    label = { Text("Прокат") },
                    icon = {}
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).padding(16.dp)) {
            when (selectedTab) {
                0 -> CatalogTab(viewModel)
                1 -> AddBookTab(viewModel) { msg -> Toast.makeText(context, msg, Toast.LENGTH_SHORT).show() }
                2 -> BorrowTab(viewModel) { msg -> Toast.makeText(context, msg, Toast.LENGTH_SHORT).show() }
            }
        }
    }
}

@Composable
fun CatalogTab(viewModel: LibraryViewModel) {
    Column {
        Text("Каталог книг та наявність:", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))
        if (viewModel.items.isEmpty()) {
            Text("Каталог порожній. Додайте книгу у вкладці '+ Книга'.", color = MaterialTheme.colorScheme.outline)
        } else {
            LazyColumn {
                items(viewModel.items) { item ->
                    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("ID: ${item.id} | '${item.title}' (${item.author}, ${item.year})", style = MaterialTheme.typography.bodyLarge)
                            val status = if (item is Book) {
                                if (item.copies > 0) "В наявності: ${item.copies} шт." else "НЕМАЄ В НАЯВНОСТІ"
                            } else "Аудіокнига (Цифрова)"
                            Text(status, color = if (item is Book && item.copies == 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddBookTab(viewModel: LibraryViewModel, showToast: (String) -> Unit) {
    var libId by remember { mutableStateOf("1") }
    var title by remember { mutableStateOf("") }
    var author by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var pages by remember { mutableStateOf("") }
    var copies by remember { mutableStateOf("1") }

    Column {
        Text("Додавання книги (Тільки Бібліотекар)", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(value = libId, onValueChange = { libId = it }, label = { Text("ID Бібліотекаря") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Назва книги") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = author, onValueChange = { author = it }, label = { Text("Автор") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = year, onValueChange = { year = it }, label = { Text("Рік видання") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = pages, onValueChange = { pages = it }, label = { Text("Кількість сторінок") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = copies, onValueChange = { copies = it }, label = { Text("Кількість примірників (шт)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())

        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                val lId = libId.toIntOrNull()
                val y = year.toIntOrNull()
                val p = pages.toIntOrNull()
                val c = copies.toIntOrNull()

                if (lId == null || y == null || p == null || c == null || title.isBlank() || author.isBlank()) {
                    showToast("Помилка: перевірте дані (букви в числах заборонені)!")
                    return@Button
                }

                val res = viewModel.service.addBook(lId, title, author, y, p, c)
                res.onSuccess {
                    showToast("Книгу '${it.title}' додано!")
                    viewModel.refreshData()
                    title = ""; author = ""; year = ""; pages = ""
                }.onFailure {
                    showToast(it.message ?: "Помилка доступу!")
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Додати в каталог")
        }
    }
}

@Composable
fun BorrowTab(viewModel: LibraryViewModel, showToast: (String) -> Unit) {
    var userId by remember { mutableStateOf("2") }
    var itemId by remember { mutableStateOf("") }

    Column {
        Text("Видача книги напрокат", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(value = userId, onValueChange = { userId = it }, label = { Text("ID Читача") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = itemId, onValueChange = { itemId = it }, label = { Text("ID Книги") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())

        Spacer(modifier = Modifier.height(16.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Button(
                onClick = {
                    val u = userId.toIntOrNull()
                    val i = itemId.toIntOrNull()
                    if (u == null || i == null) {
                        showToast("Помилка: введіть коректні цифрові ID!")
                        return@Button
                    }

                    val result = viewModel.service.borrowItem(u, i)
                    showToast(result)
                    viewModel.refreshData()
                },
                modifier = Modifier.weight(1f).padding(end = 4.dp)
            ) {
                Text("Взяти прокат")
            }

            OutlinedButton(
                onClick = {
                    val u = userId.toIntOrNull()
                    val i = itemId.toIntOrNull()
                    if (u == null || i == null) {
                        showToast("Помилка: введіть коректні цифрові ID!")
                        return@OutlinedButton
                    }

                    val result = viewModel.service.returnItem(u, i)
                    showToast(result)
                    viewModel.refreshData()
                },
                modifier = Modifier.weight(1f).padding(start = 4.dp)
            ) {
                Text("Повернути")
            }
        }
    }
}