package com.example.libraryapp

enum class Role {
    READER,
    LIBRARIAN
}

class User(
    val id: Int,
    val name: String,
    val role: Role = Role.READER,
    val maxLoan: Int = 5,
    val borrowedItems: MutableList<Int> = mutableListOf()
)