package com.example.libraryapp

abstract class Item(
    val id: Int,
    val title: String,
    val author: String,
    val year: Int
) {
    abstract val isAvailable: Boolean
}

class Book(
    id: Int,
    title: String,
    author: String,
    year: Int,
    val pages: Int,
    var copies: Int
) : Item(id, title, author, year) {
    override val isAvailable: Boolean
        get() = copies > 0
}

class AudioBook(
    id: Int,
    title: String,
    author: String,
    year: Int,
    val durationMin: Int,
    val narrator: String
) : Item(id, title, author, year) {
    override val isAvailable: Boolean = true
}