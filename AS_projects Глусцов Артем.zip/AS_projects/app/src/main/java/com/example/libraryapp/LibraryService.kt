package com.example.libraryapp

class LibraryService(
    private val itemRepo: ItemRepository,
    private val userRepo: UserRepository
) {
    init {
        registerUser("Головний Бібліотекар", Role.LIBRARIAN)
        registerUser("Читач Артем", Role.READER)
    }

    fun registerUser(name: String, role: Role = Role.READER): User {
        val user = User(id = userRepo.generateId(), name = name, role = role)
        userRepo.add(user)
        return user
    }

    fun addBook(librarianId: Int, title: String, author: String, year: Int, pages: Int, copies: Int): Result<Book> {
        val librarian = userRepo.getById(librarianId)
            ?: return Result.failure(Exception("Користувача з ID $librarianId не знайдено!"))
        if (librarian.role != Role.LIBRARIAN) {
            return Result.failure(Exception("Додавати книги має право лише Бібліотекар!"))
        }

        val book = Book(id = itemRepo.generateId(), title = title, author = author, year = year, pages = pages, copies = copies)
        itemRepo.add(book)
        return Result.success(book)
    }

    fun borrowItem(userId: Int, itemId: Int): String {
        val user = userRepo.getById(userId) ?: return "Помилка: Користувача ID=$userId не знайдено!"
        val item = itemRepo.getById(itemId) ?: return "Помилка: Книгу ID=$itemId не знайдено!"

        if (user.borrowedItems.contains(itemId)) return "Помилка: Ця книга вже у вас на руках!"
        if (user.borrowedItems.size >= user.maxLoan) return "Помилка: Перевищено ліміт книг (${user.maxLoan})!"
        if (!item.isAvailable) return "Помилка: Немає в наявності (усі примірники видано)!"

        if (item is Book) item.copies--
        user.borrowedItems.add(itemId)
        return "Успішно: '${item.title}' видано читачу ${user.name}!"
    }

    fun returnItem(userId: Int, itemId: Int): String {
        val user = userRepo.getById(userId) ?: return "Помилка: Читача не знайдено!"
        val item = itemRepo.getById(itemId) ?: return "Помилка: Книгу не знайдено!"

        if (!user.borrowedItems.contains(itemId)) return "Помилка: У читача немає цієї книги!"

        if (item is Book) item.copies++
        user.borrowedItems.remove(itemId)
        return "Успішно: '${item.title}' повернуто до бібліотеки!"
    }

    fun listAllItems(): List<Item> = itemRepo.listAll()
    fun listUsers(): List<User> = userRepo.listAll()
}