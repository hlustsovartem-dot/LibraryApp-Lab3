package com.example.libraryapp

interface Repository<T> {
    fun add(item: T): Boolean
    fun getById(id: Int): T?
    fun remove(id: Int): Boolean
    fun listAll(): List<T>
}

class ItemRepository : Repository<Item> {
    private val items = mutableListOf<Item>()
    private var nextId = 1

    override fun add(item: Item): Boolean {
        items.add(item)
        return true
    }

    fun generateId(): Int = nextId++
    override fun getById(id: Int): Item? = items.find { it.id == id }
    override fun remove(id: Int): Boolean = items.removeIf { it.id == id }
    override fun listAll(): List<Item> = items
}

class UserRepository : Repository<User> {
    private val users = mutableListOf<User>()
    private var nextId = 1

    override fun add(user: User): Boolean {
        users.add(user)
        return true
    }

    fun generateId(): Int = nextId++
    override fun getById(id: Int): User? = users.find { it.id == id }
    override fun remove(id: Int): Boolean = users.removeIf { it.id == id }
    override fun listAll(): List<User> = users
}