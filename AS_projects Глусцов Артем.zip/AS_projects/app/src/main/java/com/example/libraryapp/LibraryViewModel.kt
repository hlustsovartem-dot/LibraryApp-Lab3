package com.example.libraryapp

import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel

class LibraryViewModel : ViewModel() {
    private val itemRepo = ItemRepository()
    private val userRepo = UserRepository()
    val service = LibraryService(itemRepo, userRepo)

    val items = mutableStateListOf<Item>()
    val users = mutableStateListOf<User>()

    init {
        refreshData()
    }

    fun refreshData() {
        items.clear()
        items.addAll(service.listAllItems())
        users.clear()
        users.addAll(service.listUsers())
    }
}
